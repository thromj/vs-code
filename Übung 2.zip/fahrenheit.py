
print("Dies ist ein Celsius zu Fahrenheit rechener")
WertC = input("Geben Sie ihren Celsius wert ein " )
WertF = (float(WertC) *1.8) + 32
print("Dies entspricht ", round(WertF, 2),  "Grad Fahrenheit")
input("Drücken Sie Enter um das Programm zu schließen." )